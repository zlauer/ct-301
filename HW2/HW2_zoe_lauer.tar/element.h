#ifndef ELEMENT_H_INCLUDED
#define ELEMENT_H_INCLUDED

#include <iostream>

class element {
    public:
   // element();
    element(int newInt);
    element(double newDouble);
    element(const std::string& newVal);

    double Value() const;
    double DoubleValue() const;
    int IntValue() const;
    bool isDouble();
    void Value(double newVal);
    void changeType();

    double doubleValue;
    int intValue;
};

#endif
