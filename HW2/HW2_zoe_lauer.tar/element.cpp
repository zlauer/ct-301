#include <iostream>
#include "element.h"

/*element(){

}*/

element::element(int newInt){
    this->intValue = newInt;
}

element::element(double newDouble){
    this->doubleValue = newDouble;

}

element::element(const std::string& newVal){
    std::cout << newVal << std::endl;

}

double element::Value() const{
    return 0.0;
}

double element::DoubleValue() const{
    return element::doubleValue;
}

int element::IntValue() const{
    return this->intValue;
}

bool isDouble(){
    return false;
}

void Value(double newVal){
    std::cout << newVal << std::endl;
}

void changeType(){

}
